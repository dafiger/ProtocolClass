//
//  AppDelegate.h
//  Project_iOS
//
//  Created by wpf on 2019/4/8.
//  Copyright © 2019 dafiger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

