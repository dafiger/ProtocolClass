//
//  FirstEntry.h
//  ProtocolDemo
//
//  Created by wangpf on 2019/5/23.
//  Copyright © 2019 wpf. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "FirstProtocol.h"

#import "FirstVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface FirstEntry : NSObject<FirstProtocol>

- (UIViewController *)homePage:(NSString *)userID;

@end

NS_ASSUME_NONNULL_END
