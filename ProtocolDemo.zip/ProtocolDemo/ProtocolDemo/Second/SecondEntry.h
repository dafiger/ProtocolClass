//
//  SecondEntry.h
//  ProtocolDemo
//
//  Created by wangpf on 2019/5/23.
//  Copyright © 2019 wpf. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MediatorManager.h"
#import "SecondProtocol.h"

#import "SecondVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface SecondEntry : NSObject<SecondProtocol>

- (UIViewController *)homePage:(NSString *)userID;

@end

NS_ASSUME_NONNULL_END
