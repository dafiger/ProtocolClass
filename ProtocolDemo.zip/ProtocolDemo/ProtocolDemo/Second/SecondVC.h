//
//  SecondVC.h
//  ProtocolDemo
//
//  Created by wangpf on 2019/5/21.
//  Copyright © 2019 wpf. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SecondVC : UIViewController

@property (nonatomic, strong) NSString *userID;

@end

NS_ASSUME_NONNULL_END
